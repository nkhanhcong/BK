cd bkool
scala -cp ./bin:/Applications/scala/antlr-4.5-complete.jar bkool.Main -testphase2
cd ..