cd bkool
if [ ! -d ./bin ]; then 
	mkdir ./bin
fi
scalac -d ./bin -cp ./bin:/Applications/scala/antlr-4.5-complete.jar ./src/bkool/*.scala ../grammar/target/generated-sources/antlr4/*.java ./src/bkool/parser/*.scala 
cd ../grammar
javac -d ../bkool/bin -cp /Applications/scala/scala-2.11.2/lib/scala-library.jar:/Applications/scala/antlr-4.5-complete.jar:../bkool/bin:../bkool/bin/bkool/parser ./target/generated-sources/antlr4/*.java
cd ..