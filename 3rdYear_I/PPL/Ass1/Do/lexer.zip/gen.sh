cd MC
java -jar /Applications/scala/antlr-4.5-complete.jar -o ./target/generated-sources/antlr4 -no-listener -visitor MC.g4
cd ..