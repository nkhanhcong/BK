cd Sample
scala -cp ./bin:/Applications/scala/antlr-4.5-complete.jar mc.Main -testlexer 1 3 testcases solutions
cd ..