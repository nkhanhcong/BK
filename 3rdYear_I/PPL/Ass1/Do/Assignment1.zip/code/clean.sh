cd grammar
rm -r ./target
cd ../bkool
rm -r ./bin
cd ..