cd grammar
java -jar /Applications/scala/antlr-4.5-complete.jar -o ./target/generated-sources/antlr4 -no-listener -visitor BKOOL.g4
cd ..