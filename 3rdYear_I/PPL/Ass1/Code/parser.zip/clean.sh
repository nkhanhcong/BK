cd MC
rm -r ./target
cd ../Sample
rm -r ./bin
cd ..